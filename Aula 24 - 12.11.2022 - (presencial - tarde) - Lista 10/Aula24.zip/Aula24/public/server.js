const express = require('express');
const cors = require('cors');

const app = express();
const porta = 8080;

// Configuração do CORS
app.use(cors({ origin: '*' }));

// Instancia o servidor
app.listen(porta,
    () => console.log(`Servidor iniciado na porta ${porta}`)
);

function buscaCidades(e) {
    document.querySelector("#cidade").innerHTML = '';
}

