
    drop table if exists livro cascade;
