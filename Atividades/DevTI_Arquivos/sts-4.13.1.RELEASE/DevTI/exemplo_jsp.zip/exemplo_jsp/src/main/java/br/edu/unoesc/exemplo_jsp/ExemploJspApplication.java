package br.edu.unoesc.exemplo_jsp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExemploJspApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExemploJspApplication.class, args);
	}

}
