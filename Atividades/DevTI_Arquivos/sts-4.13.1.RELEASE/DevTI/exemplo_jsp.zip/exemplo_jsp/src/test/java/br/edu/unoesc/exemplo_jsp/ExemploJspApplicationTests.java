package br.edu.unoesc.exemplo_jsp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExemploJspApplicationTests {

	@Test
	void contextLoads() {
	}

}
