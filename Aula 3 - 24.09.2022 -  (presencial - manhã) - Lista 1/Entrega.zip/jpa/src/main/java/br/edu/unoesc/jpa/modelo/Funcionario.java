//package br.edu.unoesc.jpa.modelo;
//
//import java.io.Serializable;
//import java.math.BigDecimal;
//import java.time.LocalDate;
//import java.util.List;
//
//import jakarta.persistence.CascadeType;
//import jakarta.persistence.Column;
//import jakarta.persistence.Entity;
//import jakarta.persistence.FetchType;
//import jakarta.persistence.GeneratedValue;
//import jakarta.persistence.GenerationType;
//import jakarta.persistence.Id;
//import jakarta.persistence.JoinColumn;
//import jakarta.persistence.JoinTable;
//import jakarta.persistence.ManyToMany;
//import jakarta.persistence.Table;
//import jakarta.persistence.Temporal;
//import jakarta.persistence.TemporalType;
//
//
//public class Funcionario {
//
//	@Entity
//	@Table(name = "funcionarios")
//	public class Funcionarios implements Serializable {
//		private static final long serialVersionUID = 1L;
//
//		@Id
//		@GeneratedValue(strategy = GenerationType.IDENTITY)
//		private Integer codigo;
//		
//		@Column(nullable = false, length = 50)
//		private String nome;
//		
//		@Temporal(TemporalType.DATE)
//		@Column(name = "data_nascimento", nullable = false)
//		private LocalDate dataNascimento;
//		
//		@Column(nullable = false, precision = 12, scale = 2)
//		private BigDecimal salario;
//		
//		@ManyToMany(cascade = CascadeType.ALL, 
//				fetch = FetchType.EAGER)
//		@JoinTable(name = "funcionarios_projeto",
//				   joinColumns = @JoinColumn(name = "id_funcionario"),
//				   inverseJoinColumns = @JoinColumn(name = "id_projeto"))
//		private List<Projeto> projetosFuncionarios;
////		
////		public void adicionarProjeto(Projeto projeto) {
////			if (projeto != null && !this.getprojetosFuncionarios().contains(projeto)) {
////				this.projetosFuncionarios.add(projeto);
////				
////				if (!projeto.getClass() .contains(this)) {
////					projeto.().add(this);
////				}
////			}
////		}
//
//		public Funcionarios() {
//			super();
//		}
//
//		public Funcionarios(String nome, LocalDate dataNascimento, BigDecimal salario) {
//			super();
//			this.nome = nome;
//			this.dataNascimento = dataNascimento;
//			this.salario = salario;
//		}
//		
//
//		public List<Projeto> getprojetosFuncionarios() {
//			return projetosFuncionarios;
//		}
//
//		public void setprojetosFuncionarios(List<Projeto> projetosFuncionarios) {
//			this.projetosFuncionarios = projetosFuncionarios;
//		}
//
//		@Override
//		public String toString() {
//			return "Funcionarios [codigo=" + codigo + ", nome=" + nome + ", dataNascimento=" + dataNascimento
//					+ ", salario=" + salario + "]";
//		}		
//	}
//}

package br.edu.unoesc.jpa.modelo;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.Table;

@Entity
@Table(name = "funcionarios")
public class Funcionario implements Serializable {
	private static final long serialVersionUID = 1L;
	@Id
//	@Column(name = "id_funcionario")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer codigo;

	@Column(length = 50, nullable = false)
	private String nome;

	@Column(name = "data_nascimento", nullable = false)
	private LocalDate dataNascimento;

	@Column(precision = 12, scale = 2, nullable = false)
	private BigDecimal salario;

	@ManyToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinTable(name = "funcionarios_projeto", joinColumns = @JoinColumn(name = "id_funcionario"), inverseJoinColumns = @JoinColumn(name = "id_projeto"))
	private List<Projeto> projetosFuncionario;
	


	public Funcionario() {
	}

	public Funcionario(String nome, LocalDate dataNascimento, BigDecimal salario) {
		this.nome = nome;
		this.dataNascimento = dataNascimento;
		this.salario = salario;
	}

	public Integer getCodigo() {
		return codigo;
	}

	public String getNome() {
		return nome;
	}

	public void adicionarProjeto(Projeto projeto) {
		if (projeto != null && !this.getProjetos().contains(projeto)) {
			this.projetosFuncionario.add(projeto);
			if (!projeto.getFuncionarios().contains(this)) {
				projeto.getFuncionarios().add(this);
			}
		}
	}

	public List<Projeto> getProjetos() {
		if (projetosFuncionario == null) {
			projetosFuncionario = new ArrayList<>();
		}
		return projetosFuncionario;
	}

	@Override
	public String toString() {
		return " " + codigo + " - " + nome;
	}

}
