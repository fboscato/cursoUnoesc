package br.edu.unoesc.jpa.app;

import br.edu.unoesc.jpa.util.JPAUtil;
import jakarta.persistence.EntityManager;

public class App {

	private static EntityManager em;
	
	private static void adicionarDados() {
		em = JPAUtil.getEntityManager();
		System.out.println("Adicionou");
		em.close();
	}
	
	private static void ListarPorProjeto() {
		em = JPAUtil.getEntityManager();
		
		em.close();
	}
	
	private static void listarPorFuncionario() {
		em = JPAUtil.getEntityManager();
		
		em.close();
	}
	public static void main(String[] args) {
			
		adicionarDados();
	}

}
