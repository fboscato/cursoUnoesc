package br.edu.unoesc.jpa.app;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import br.edu.unoesc.jpa.modelo.Funcionario;
import br.edu.unoesc.jpa.modelo.Projeto;
import br.edu.unoesc.jpa.util.JPAUtil;
import jakarta.persistence.EntityManager;

public class App {
	public static EntityManager em;

	private static void listarPorFuncionario() {
		em = JPAUtil.getEntityManager();
		
		String jpql = "SELECT f FROM Funcionario f";
		List<Funcionario> funcionarios = em.createQuery(jpql, Funcionario.class)
									 	   .getResultList();
		
		for (Funcionario f : funcionarios) {
			System.out.println(f.getCodigo() + " - " + f.getNome());
			
			for (Projeto p : f.getProjetos()) {
				System.out.println("\t\t" + p.getCodigo() + " - " + p.getNome());
			}
			
			System.out.println();
		}
		
		em.close();
	}
	
	private static void listarPorProjeto() {
		em = JPAUtil.getEntityManager();
		
		String jpql = "SELECT p FROM Projeto p";
		List<Projeto> projetos = em.createQuery(jpql, Projeto.class)
								   .getResultList();
		
		for (Projeto p : projetos) {
			System.out.println(p.getCodigo() + " - " + p.getNome());
			
			for (Funcionario f : p.getFuncionarios()) {
				System.out.println("\t\t" + f.getCodigo() + " - " + f.getNome());
			}
			
			System.out.println();
		}
		
		em.close();
	}

	private static void adicionarDados() {
		em = JPAUtil.getEntityManager();
		
		Projeto p1 = new Projeto("Projeto Manhattan");
		Projeto p2 = new Projeto("Projeto Genoma Humano");
		
		Funcionario f1 = new Funcionario("Fulano", 
									     LocalDate.now(), 
									     new BigDecimal("3000.00"));
		
		Funcionario f2 = new Funcionario("Beltrano", 
										 LocalDate.parse("25/12/2022", 
												 	     DateTimeFormatter.ofPattern("dd/MM/yyyy")),
									     new BigDecimal("4000.00"));
		
		Funcionario f3 = new Funcionario("Sicrano", 
				 						 LocalDate.parse("13/08/2022", 
				 								 		 DateTimeFormatter.ofPattern("dd/MM/yyyy")),
				 						 new BigDecimal("5000.00"));
		
		p1.adicionarFuncionario(f1);
		p1.adicionarFuncionario(f2);
		
		f1.adicionarProjeto(p2);
		f3.adicionarProjeto(p2);
		
		em.getTransaction().begin();
		em.persist(f1);
		em.persist(f2);
		em.persist(f3);
		em.getTransaction().commit();

		em.close();
	}
	
	public static void main(String[] args) {
		adicionarDados();
//		listarPorFuncionario();
		listarPorProjeto();
	}

}
