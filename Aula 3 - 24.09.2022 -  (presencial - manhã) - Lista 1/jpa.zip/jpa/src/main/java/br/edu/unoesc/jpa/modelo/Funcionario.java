package br.edu.unoesc.jpa.modelo;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.Table;

@Entity
@Table(name = "funcionarios")
public class Funcionario implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer codigo;
	
	@Column(nullable = false, length = 50)
	private String nome;
	
	@Column(name = "data_nascimento", nullable = false)
	private LocalDate dataNascimento;
	
	@Column(nullable = false, precision = 12, scale = 2)
	private BigDecimal salario;
	
	@ManyToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinTable(
			joinColumns = @JoinColumn(name = "id_funcionario"),
			inverseJoinColumns = @JoinColumn(name = "id_projeto"))
	List<Projeto> projetos;
	
	public Funcionario() { }

	public Funcionario(String nome, LocalDate dataNascimento, BigDecimal salario) {
		this.nome = nome;
		this.dataNascimento = dataNascimento;
		this.salario = salario;
	}

	public void adicionarProjeto(Projeto projeto) {
		if (projeto != null && !this.getProjetos().contains(projeto)) {
			this.projetos.add(projeto);
			
			if (!projeto.getFuncionarios().contains(this)) {
				projeto.getFuncionarios().add(this);
			}
		}
	}
	
	public List<Projeto> getProjetos() {
		if (this.projetos == null) {
			this.projetos = new ArrayList<>();
		}
		
		return projetos;
	}

	public void setProjetos(List<Projeto> projetos) {
		this.projetos = projetos;
	}

	public Integer getCodigo() { return codigo; }
	public void setId(Integer codigo) { this.codigo = codigo; }

	public String getNome() { return nome; }
	public void setNome(String nome) { this.nome = nome; }

	public LocalDate getDataNascimento() { return dataNascimento;}
	public void setDataNascimento(LocalDate dataNascimento) { this.dataNascimento = dataNascimento; }
 
	public BigDecimal getSalario() { return salario; }
	public void setSalario(BigDecimal salario) { this.salario = salario; }

	@Override
	public String toString() {
		return "Funcionario [codigo=" + codigo + ", nome=" + nome + ", dataNascimento=" + dataNascimento + ", salario="
				+ salario + "]";
	}
}