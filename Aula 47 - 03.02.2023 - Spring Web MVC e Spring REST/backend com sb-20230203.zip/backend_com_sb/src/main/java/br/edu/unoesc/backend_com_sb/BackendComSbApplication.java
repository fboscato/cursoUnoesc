package br.edu.unoesc.backend_com_sb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackendComSbApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackendComSbApplication.class, args);
	}

}
