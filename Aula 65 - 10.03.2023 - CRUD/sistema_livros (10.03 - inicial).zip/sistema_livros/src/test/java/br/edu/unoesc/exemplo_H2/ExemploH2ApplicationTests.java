package br.edu.unoesc.exemplo_H2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExemploH2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
