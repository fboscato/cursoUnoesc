package br.edu.unoesc.teste_templates;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TesteTemplatesApplication {

	public static void main(String[] args) {
		SpringApplication.run(TesteTemplatesApplication.class, args);
	}

}
