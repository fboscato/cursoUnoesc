package br.edu.unoesc.teste_templates.controller;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.ModelAndView;

import br.edu.unoesc.teste_templates.model.Aluno;
import br.edu.unoesc.teste_templates.model.Pessoa;

@Controller
public class TesteController {
	@GetMapping("/")
	public String home(Model modelo) {
		Map<String, Object> dados = new HashMap<String, Object>();
		dados.put("valor", 42);
		dados.put("curso", "DEV-TI");
		
		modelo.addAttribute("nome", "Unoesc");
		modelo.addAttribute("dados", dados);
		
		return "index";
	}
	
	@GetMapping("/perfil")
	public ModelAndView perfil(Model modelo) {
		modelo.addAttribute("pessoa", new Pessoa(1L,
											   "Sr.",
											   "Herculano",
											   "De Biasi",
											   new GregorianCalendar(1975, 5, 6).getTime(),
											   LocalDate.of(1975, 6, 6),
											   LocalDateTime.of(1975, 6, 6, 2, 0),
											   Instant.now(),
											   new BigDecimal("123.45")
										   ));
			
		return new ModelAndView("perfil");
	}
	
	@GetMapping("/recursos")
	public String recursos(ModelMap model) {
		model.addAttribute("frutas", List.of(
											"Maçã",
											"Banana",
											"Mamão"
										));

		Aluno a1 = new Aluno(1L, "Fulano", Arrays.asList("Ler", "Ver TV", "Caminhar"));
		Aluno a2 = new Aluno(2L, "Beltrano", Arrays.asList("Ouvir música", "Dançar"));
		Aluno a3 = new Aluno(3L, "Sicrano", Arrays.asList("Estudar"));
		
		model.addAttribute("aluno", a3);
				
		return "recursos";
	}
}
