INSERT INTO aluno (nome, salario, nascimento) VALUES ('Fulano', 123.45, '1975-06-06');
INSERT INTO aluno (nome, salario, nascimento) VALUES ('Beltrano', 234.56, '2000-12-31');