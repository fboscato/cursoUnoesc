package br.edu.unoesc.exemplo_thymeleaf;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExemploThymeleafApplicationTests {

	@Test
	void contextLoads() {
	}

}
