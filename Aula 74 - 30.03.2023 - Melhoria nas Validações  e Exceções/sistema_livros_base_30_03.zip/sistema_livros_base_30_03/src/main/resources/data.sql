INSERT INTO livro (titulo, paginas, autor) VALUES ('O senhor dos anéis', 1000, 'Tolkien');
INSERT INTO livro (titulo, paginas, autor) VALUES ('Spring Boot', 328, 'Mark Heckler');