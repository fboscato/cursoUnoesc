package br.edu.unoesc.exemplo_thymeleaf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExemploThymeleafApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExemploThymeleafApplication.class, args);
	}

}
